import { Component, OnInit } from '@angular/core';
import {UserService} from '../Services/user.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  UsersData:Array<any> = [];
  userKey:string;
  constructor(    private userService: UserService,
    ) { }

  ngOnInit() {
    let loggeduser = JSON.parse(localStorage.getItem('currentUser'));
    this.userKey = localStorage.getItem('accesstoken');
    console.log(this.userKey);
    this.getAllusers();
  }
  getAllusers() {
    let userData = {"key" : this.userKey, "j":{}};
    this.userService.getUsers(userData)
    .subscribe(
      (data: any) => {
        this.UsersData.push(data);
        console.log(this.UsersData);
        console.log(data);
      }
    );
  }
}
