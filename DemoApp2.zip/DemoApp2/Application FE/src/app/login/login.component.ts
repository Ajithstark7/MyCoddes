import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import {AuthenticationService} from '../Services/authentication.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  private isloggedIn: boolean = false;
  private loggedInUser = null;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private router: Router) {
      // redirect to home if already logged in
      if (this.authenticationService.currentUserValue) { 
        this.router.navigate(['/']);
    }
     }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });

  // get return url from route parameters or default to '/'
  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/home';
  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }
  logout() {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('profile');
    
  }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
    let username = this.f.username.value;
    let password = this.f.password.value;
    let userData = { "login": username, "password": password };
     this.authenticationService.login(this.f.username.value, this.f.password.value)
            
            .subscribe(
                data => {
                   
                    console.log('user',data);
                    let resp = data.token;
                    localStorage.setItem('accesstoken',resp);
                    console.log('tokendata',resp);
                    this.router.navigate(['/home']);
                   
                });
                
  }

  getLoggedInUser() {
    return this.loggedInUser;

  }
  logoutUser(): void {
    this.isloggedIn = false;
  

  }
}
