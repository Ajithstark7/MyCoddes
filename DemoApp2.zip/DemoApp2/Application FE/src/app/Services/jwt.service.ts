import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment} from '../../environments/environment';
import { tap } from 'rxjs/operators';

const apiUrl = environment.apiUrl;


@Injectable({
  providedIn: 'root'
})
export class JwtService {

  constructor(private httpClient:HttpClient) { }

  login(username:string,password:string) {
    return this.httpClient.post<{access_token:string}>(apiUrl + 'userlogin',{username,password}).pipe(tap(res=>{
      // store user details and jwt token in local storage to keep user logged in between page refreshes
      localStorage.setItem('access token',res.access_token);
    }))
  }

//   register(user: any) {
//     return this.httpClient.post<{access_token:string}>(apiUrl + 'user', user);
// }

register(username:string,password:string) {
  return this.httpClient.post<{access_token:string}>(apiUrl + 'userregister',{username,password}).pipe(tap(res=>{
    // store user details and jwt token in local storage to keep user logged in between page refreshes
    this.login(username,password);
  }))
}

logout() {
  localStorage.removeItem('access_token');
}

public get loggedIn():boolean {
  return localStorage.getItem('access_token') !== null;
}
}
