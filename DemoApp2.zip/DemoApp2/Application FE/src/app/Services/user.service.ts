import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';

import { User } from '../models/user';
import {environment} from '../../environments/environment';
import { tap } from 'rxjs/operators';


const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

const apiUrl = environment.apiUrl;

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

    getAllusers() {
        return this.http.get<User[]>(apiUrl + '/users');
    }
    getUsers(users:any) {

        return this.http.get(apiUrl +'getusers');
    }



    getById(id: number) {
        return this.http.get(`${apiUrl}/users/` + id);
    }

    // register(user: User) {
    //     return this.http.post(apiUrl + 'adduser', user);
    // }
    register(user:any) {
        return this.http.post<{access_token:string}>(apiUrl + 'adduser',user).pipe(tap(res=>{
          // store user details and jwt token in local storage to keep user logged in between page refreshes
        //   this.login(username,password);
        }))
      }
    login(user:User){
        return this.http.post(apiUrl + 'userlogin', user);
    }
    update(user: User) {
        return this.http.put(`${apiUrl}/users/` + user.id, user);
    }

    delete(id: number) {
        return this.http.delete(`${apiUrl}/users/` + id);
    }
  }