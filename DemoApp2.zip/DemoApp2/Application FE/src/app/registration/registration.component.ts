import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import {UserService} from '../Services/user.service';
import { AuthenticationService } from '../Services/authentication.service';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  registerForm: FormGroup;
  loading = false;
  submitted = false;
  registerDatas :Array<any> = [];
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    private authService: AuthenticationService
  ) { }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstname: ['', Validators.required],
      lastname: ['', Validators.required],
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]]
  });
  }

   // convenience getter for easy access to form fields
   get f() { return this.registerForm.controls; }

   onSubmit() {
       this.submitted = true;
        console.log('clicked');
       // stop here if form is invalid
       if (this.registerForm.invalid) {
           return;
       }

       this.loading = true;
       const userData = this.registerForm.value;
       console.log('data',userData)
       this.authService.register(userData)
            .pipe(first())
            .subscribe((data:any) => {
                  console.log('registerd user',data);
                  this.registerForm.reset();
                  this.router.navigate(['/login']);
      }

            )}
}
