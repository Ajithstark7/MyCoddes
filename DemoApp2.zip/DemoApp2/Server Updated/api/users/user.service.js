const pool = require("../../config/database");


module.exports = {
    create:(data,callBack)=>{
        pool.query (
            'insert into users(firstname,lastname,username,password) values(?,?,?,?)',[
                data.firstname,
                data.lastname,
                data.username,
                data.password,

            ],
            (error,results,fields)=>{
                if(error) {
                    callBack(error);
                }
                return callBack(null,results);
            }
        );
            
        },

     getUsers:callBack=> {
         pool.query(
            'select id,firstname,lastname,username,password from users ',
            [],
                (error,results,fields)=> {
                    if(error){
                        callBack(error);
                    }
                    return callBack(null,results);
                }
            
         );
     },   

     getUserById:(id,callBack) => {
        pool.query(

           'select id,firstname,lastname,username,password from users where id = ? ',[id],
           
               (error,results,fields)=> {
                   if(error){
                       callBack(error);
                   }
                   return callBack(null,results[0]);
               }
           
        );
    },
    
    updateUser:(data,callBack)=>{
        pool.query (
            'update users set firstname = ?,lastname = ?,username = ? ,password = ?  where id = ?',
            [
                data.firstname,
                data.lastname,
                data.username,
                data.password,
                data.id,
            ],
            (error,results,fields)=>{
                if(error) {
                    callBack(error);
                }
                return callBack(null,results);
            }
        );
            
        },

        deleteUser :(data,callBack)=> {
            pool.query(
               'delete from users where id = ? ',[data.id],
               
                   (error,results,fields)=> {
                       if(error){
                           callBack(error);
                       }
                       return callBack(null,results);
                   }
               
            );
        },
        
        getUseryUserName:(username,callBack) => {
            pool.query(
                "select * from users where username = ?", [username],
                (error,results,fields)=>{
                    if(error) {
                        callBack(error);
                    }
                    return callBack(null,results[0]);
                                }
            );
        }    
};