const { createUser,
    getUserById,
    getUsers,
    deleteUser,
    updateUser,
    login } = require("../users/user.controller");
const router = require("express").Router();

const {checkToken} = require("../../auth/token_validation");


router.post("/adduser", checkToken,createUser);
router.get("/getusers",checkToken, getUsers);
router.get("/:id", checkToken,getUserById);
router.delete("/deleteuser", checkToken,deleteUser);
router.patch("/updateuser", checkToken,updateUser);
router.post("/login", login);
module.exports = router;